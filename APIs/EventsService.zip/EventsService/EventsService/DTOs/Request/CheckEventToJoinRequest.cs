﻿namespace EventsService.DTOs.Request
{
    public class CheckEventToJoinRequest
    {
        public int EventId { get; set; }
        public int UserId { get; set; }
    }
}
