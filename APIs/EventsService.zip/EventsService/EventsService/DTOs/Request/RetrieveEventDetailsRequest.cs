﻿namespace EventsService.DTOs.Request
{
    public class RetrieveEventDetailsRequest
    {
        public int EventId { get; set; }
        public int UserId { get; set; }
    }
}
