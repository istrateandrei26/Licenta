﻿namespace EventsService.DTOs.Request
{
    public class RetrieveEventInvitesRequest
    {
        public int UserId { get; set; }
    }
}
