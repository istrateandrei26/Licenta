﻿namespace EventsService.DTOs.Request
{
    public class RetrieveLocationsBySportCategoryRequest
    {
        public int UserId { get; set; }
        public int SportCategoryId { get; set; }
    }
}
