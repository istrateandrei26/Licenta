﻿namespace EventsService.DTOs.Request
{
    public class ApproveNewLocationRequest
    {
        public int ApprovedLocationId { get; set; }
    }
}
