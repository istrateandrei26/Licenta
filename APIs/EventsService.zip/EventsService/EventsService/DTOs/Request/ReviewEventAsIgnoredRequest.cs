﻿namespace EventsService.DTOs.Request
{
    public class ReviewEventAsIgnoredRequest
    {
        public int EventId { get; set; }
        public int FromId { get; set; }
    }
}
