﻿namespace EventsService.DTOs.Request
{
    public class GetAttendedLocationsRequest
    {
        public int UserId { get; set; }
    }
}
