﻿namespace EventsService.DTOs.Request
{
    public class GetRecommendedFriendsRequest
    {
        public int UserId { get; set; }
    }
}
