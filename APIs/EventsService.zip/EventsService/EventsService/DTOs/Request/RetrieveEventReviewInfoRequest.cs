﻿namespace EventsService.DTOs.Request
{
    public class RetrieveEventReviewInfoRequest
    {
        public int UserId { get; set; }
    }
}
