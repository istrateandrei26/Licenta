﻿namespace EventsService.DTOs.Request
{
    public class GetNewRequestedLocationInfoForPaymentRequest
    {
        public string VerificationCode { get; set; } = string.Empty;
    }
}
