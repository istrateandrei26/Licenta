﻿namespace EventsService.DTOs.Response
{
    public class CreateNewLocationResponse : BasicResponse
    {
        public double LocationId { get; set; }
    }
}
