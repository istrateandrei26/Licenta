﻿namespace EventsService.DTOs.Response
{
    public class GenerateNewLocationResponse : BasicResponse
    {
        public bool Success { get; set; }
    }
}
