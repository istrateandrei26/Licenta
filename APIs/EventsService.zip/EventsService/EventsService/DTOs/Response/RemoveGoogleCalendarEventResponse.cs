﻿namespace EventsService.DTOs.Response
{
    public class RemoveGoogleCalendarEventResponse: BasicResponse
    {
    }
}
