﻿namespace EventsService.DTOs.Response
{
    public class ReviewEventAsIgnoredResponse : BasicResponse
    {
    }
}
