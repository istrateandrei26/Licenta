﻿namespace EventsService.DTOs.Response
{
    public class ConfirmNewLocationPaymentResponse : BasicResponse
    {
    }
}
