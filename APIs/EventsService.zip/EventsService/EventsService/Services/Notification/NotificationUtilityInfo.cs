﻿namespace EventsService.Services.Notification
{
    public class NotificationUtilityInfo
    {
        public static string EVENT_DETAILS_SCREEN = "/EventDetailsView";
        public static string EVENT_INVITES_VIEW = "/EventInvitesView";
    }
}
